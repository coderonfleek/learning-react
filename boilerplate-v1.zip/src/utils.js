console.log("Its utils baby");

const square = x => x * x;

const add = (a, b) => a + b;

export { square, add };
